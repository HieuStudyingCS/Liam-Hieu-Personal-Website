# Personal website

Website học thuật cá nhân xây bằng [Astro](https://astro.build): Home, Portfolio, Publications, Blog (song ngữ Anh – Việt, mục lục bên trái, KaTeX), News, chế độ sáng/tối và tìm kiếm.

Giai đoạn hiện tại: **chạy trên localhost**. Deploy lên Cloudflare và gắn tên miền làm ở bước sau.

## Chạy lần đầu

Cần [Node.js](https://nodejs.org) bản LTS (20 hoặc 22 trở lên). Mở terminal (PowerShell hoặc terminal của VS Code) tại thư mục này:

```bash
npm install      # chỉ cần chạy một lần (hoặc khi đổi package.json)
npm run dev      # mở http://localhost:4321
```

Trang tự tải lại mỗi khi bạn lưu file. Dừng server bằng `Ctrl + C`.

| Lệnh | Việc làm |
| --- | --- |
| `npm run dev` | Chạy thử trên localhost, hiện cả bài nháp |
| `npm run build` | Build bản tĩnh vào `dist/` (giống khi deploy), báo lỗi nếu nội dung sai định dạng |
| `npm run preview` | Xem bản đã build ở localhost |
| `npm run check` | Kiểm tra kiểu TypeScript và frontmatter |
| `npm run new "Tiêu đề"` | Tạo bài blog mới (tiếng Anh) |
| `npm run new "Tiêu đề" -- --lang vi` | Tạo bài blog mới (tiếng Việt) |
| `npm run translate <thư-mục-bài>` | Tạo bản tiếng Việt từ bản tiếng Anh (`-- --to en` để làm ngược lại) |

## Cập nhật nội dung

Mọi thứ cần sửa thường xuyên nằm ở hai chỗ: `src/content/blog/` và `src/data/`. Không cần đụng vào code giao diện.

### Đăng bài blog

1. `npm run new "Bayesian Optimization từ con số 0"` → tạo `src/content/blog/<ngày>-<slug>/en.md` với `draft: true`.
2. Viết bằng Markdown. Ảnh đặt cùng thư mục, chèn bằng `![Chú thích](./hinh.png)`. Toán viết như LaTeX: `$x$` hoặc `$$ ... $$`. Chú thích cuối trang: `[^1]`.
3. Xem trước với `npm run dev`.
4. Đổi `draft: false` là bài sẽ xuất hiện khi build/deploy.

Frontmatter đầy đủ:

```yaml
---
title: "Tiêu đề"
description: "Một câu tóm tắt, hiện ở danh sách bài"
pubDate: 2026-11-20
updatedDate: 2026-11-22                # tuỳ chọn
tags: [bayesian optimization, gaussian process]
series: "Black-box Optimization 101"   # tuỳ chọn: gom bài thành chuỗi
cover: ./cover.png                     # tuỳ chọn: ảnh bìa / thumbnail
draft: false
---
```

- Mỗi bài là một thư mục; `en.md` và `vi.md` trong cùng thư mục là hai bản của cùng một bài (dùng chung ảnh). Bài chỉ có một bản vẫn đăng bình thường.
- Mục lục bên trái lấy từ các heading `##` và `###`.
- Bài có `pubDate` ở tương lai sẽ chỉ hiện từ ngày đó (khi build).

### Thông tin cá nhân, publications, news, dự án

| File | Nội dung |
| --- | --- |
| `src/data/profile.yaml` | Tên, đơn vị, câu giới thiệu (có tooltip `[[từ khóa\|giải thích]]`), bio, link, hướng nghiên cứu, tech stack |
| `src/data/publications.yaml` | Publications; `selected: true` để hiện ở trang chủ |
| `src/data/news.yaml` | Tin tức, mới nhất ở trên |
| `src/data/projects.yaml` | Dự án ở trang Portfolio (lọc theo `category`) |
| `src/data/education.yaml`, `experience.yaml` | Học vấn, kinh nghiệm |

Văn bản song ngữ viết dạng `{ en: "...", vi: "..." }` hoặc một chuỗi dùng chung. Mỗi mục trong file dạng danh sách cần một `id` không trùng.

**Việc cần làm ngay:** thay các mục ghi "VÍ DỤ / example" bằng thông tin thật, chép ảnh đại diện vào `public/avatar.jpg` (rồi sửa `avatar` trong `profile.yaml`), chép CV vào `public/cv.pdf`, điền link GitHub/Scholar.

## Cấu trúc thư mục

```text
src/
├── content/blog/<thu-muc-bai>/{en,vi}.md   # bài viết + ảnh
├── data/*.yaml                             # dữ liệu các trang
├── content.config.ts                       # schema kiểm tra frontmatter và YAML
├── config.ts                               # bật/tắt bình luận Giscus, bộ đếm lượt xem
├── i18n/ui.ts                              # chữ giao diện tiếng Anh / tiếng Việt
├── styles/global.css                       # màu, font, bố cục (design tokens ở đầu file)
├── layouts/                                # BaseLayout, PostLayout
├── components/                             # Header, Toc, PostRow, PubItem, Search, ...
├── views/                                  # nội dung từng trang, dùng chung cho EN và VI
└── pages/                                  # đường dẫn: /, /portfolio, /blog, ... và /vi/...
public/                                     # avatar, CV, favicon
scripts/                                    # new-post.mjs, translate.mjs
```

URL: tiếng Anh ở `/`, tiếng Việt ở `/vi/`. Nút **EN / VI** trên thanh điều hướng chuyển sang trang tương ứng (hoặc về blog ngôn ngữ kia nếu bài chưa có bản dịch).

## Để dành cho giai đoạn deploy

- `site` trong `astro.config.mjs`: đổi `https://example.com` thành tên miền thật.
- Bình luận Giscus và bộ đếm lượt xem: đã có sẵn component, đang tắt trong `src/config.ts`.
- Deploy lên Cloudflare, gắn tên miền, GitHub Actions: theo tài liệu kế hoạch.

## Ghi chú kỹ thuật

- Giao diện dùng CSS thuần với biến màu (design tokens) thay vì Tailwind, để đợt redesign chỉ cần sửa khối `:root` trong `src/styles/global.css`.
- Tìm kiếm (`Ctrl K` hoặc `/`) dùng chỉ mục `search.json` sinh lúc build, chạy được cả trên localhost, không cần dịch vụ ngoài.
- Nâng cấp Astro lên bản mới về sau: `npx @astrojs/upgrade`.
